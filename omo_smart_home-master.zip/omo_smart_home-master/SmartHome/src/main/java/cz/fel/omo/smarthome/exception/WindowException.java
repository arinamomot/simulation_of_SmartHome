package cz.fel.omo.smarthome.exception;

/**
 * The type Window exception.
 */
public class WindowException extends Exception {
	public WindowException(String message) {
		super(message);
	}
}
