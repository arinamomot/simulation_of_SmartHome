package cz.fel.omo.smarthome.entity.inhabitants.person;

/**
 * The type Baby.
 */
public class Baby extends Person{
	public Baby(int id, String name) {
		super(id, name);
		type = "Baby";
	}
}
