package cz.fel.omo.smarthome.exception;

/**
 * The type Creation exception.
 */
public class CreationException extends Exception {
	public CreationException(String message) {
		super(message);
	}
}
