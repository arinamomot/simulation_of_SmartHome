package cz.fel.omo.smarthome.entity.inhabitants.person;

/**
 * The type Daughter.
 */
public class Daughter extends Person {
	public Daughter(int id, String name) {
		super(id, name);
		type = "Daughter";
	}
}
