package cz.fel.omo.smarthome.entity.inhabitants.person;

/**
 * The type Son.
 */
public class Son extends Person{
	public Son(int id, String name) {
		super(id, name);
		type = "Son";
	}
}
