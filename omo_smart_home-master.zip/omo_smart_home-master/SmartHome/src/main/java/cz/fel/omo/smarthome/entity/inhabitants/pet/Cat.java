package cz.fel.omo.smarthome.entity.inhabitants.pet;

/**
 * The type Cat.
 */
public class Cat extends Pet {
	public Cat(int id, String name) {
		super(id, name);
		type = "Cat";
	}
}
