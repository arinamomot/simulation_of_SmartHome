package cz.fel.omo.smarthome.entity.devices;

/**
 * The type Documentation.
 */
public class Documentation {
	public String text;
	public String type;
	
	public Documentation(String type) {
		this.type = type;
	}
}
