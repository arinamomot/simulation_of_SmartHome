package cz.fel.omo.smarthome.entity.inhabitants.person;

/**
 * The type Grand father.
 */
public class GrandFather extends Person {
	public GrandFather(int id, String name) {
		super(id, name);
		type = "GrandFather";
	}
}
