package cz.fel.omo.smarthome.entity.inhabitants.person;

/**
 * The type Father.
 */
public class Father extends Person {
	public Father(int id, String name) {
		super(id, name);
		type = "Father";
	}
}
