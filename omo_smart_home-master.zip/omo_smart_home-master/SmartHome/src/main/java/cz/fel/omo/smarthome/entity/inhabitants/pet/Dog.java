package cz.fel.omo.smarthome.entity.inhabitants.pet;

/**
 * The type Dog.
 */
public class Dog extends Pet {
	public Dog(int id, String name) {
		super(id, name);
		type = "Dog";
	}
}
