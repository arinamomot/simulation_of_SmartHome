package cz.fel.omo.smarthome.exception;

/**
 * The type Sensor exception.
 */
public class SensorException extends Exception {
	public SensorException(String message) {
		super(message);
	}
}
