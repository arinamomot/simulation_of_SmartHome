package cz.fel.omo.smarthome.exception;

/**
 * The type Device exception.
 */
public class DeviceException extends Exception {
    public DeviceException(String message) {
        super(message);
    }
}
