package cz.fel.omo.smarthome.exception;

/**
 * The type Vehicle exception.
 */
public class VehicleException extends Exception{
	public VehicleException(String message) {
		super(message);
	}
}
