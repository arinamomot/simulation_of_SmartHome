package cz.fel.omo.smarthome.entity.inhabitants.person;

/**
 * The type Mother.
 */
public class Mother extends Person {
	public Mother(int id, String name) {
		super(id, name);
		type = "Mother";
	}
}
