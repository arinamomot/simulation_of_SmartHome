package cz.fel.omo.smarthome.entity.inhabitants.pet;

/**
 * The type Parrot.
 */
public class Parrot extends Pet {
	public Parrot(int id, String name) {
		super(id, name);
		type = "Parrot";
	}
}
