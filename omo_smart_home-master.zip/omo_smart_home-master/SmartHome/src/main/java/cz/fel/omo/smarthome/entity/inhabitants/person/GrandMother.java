package cz.fel.omo.smarthome.entity.inhabitants.person;

/**
 * The type Grand mother.
 */
public class GrandMother extends Person{
	public GrandMother(int id, String name) {
		super(id, name);
		type = "GrandMother";
	}
}
