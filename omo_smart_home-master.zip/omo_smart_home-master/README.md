# Semestrální práce : "Smart Home" OMO

## 1.	Tým

   * Štěpán Bořek, borekste@fel.cvut.cz  
   * Arina Momot, momotari@fel.cvut.cz 

## 2.	Téma semestrální práce

   Smart Home

## 3.	Stručný popis

Simulation of a smart home.

## 4.   Funkční požadavky

**1. F1 :**

- Devices, Inhabitants, Vehicles - src/main/java/cz/fel/omo/smarthome/entity (https://gitlab.fel.cvut.cz/momotari/omo_smart_home/-/tree/master/SmartHome/src/main/java/cz/fel/omo/smarthome/entity)
- House, Floor, Room, Light, Sensors, Window - src/main/java/cz/fel/omo/smarthome/house (https://gitlab.fel.cvut.cz/momotari/omo_smart_home/-/tree/master/SmartHome/src/main/java/cz/fel/omo/smarthome/house)

**2. F2 :**

- Stav zařízení - src/main/java/cz/fel/omo/smarthome/entity/devices/deviceState (https://gitlab.fel.cvut.cz/momotari/omo_smart_home/-/tree/master/SmartHome/src/main/java/cz/fel/omo/smarthome/entity/devices/deviceState)
- API na ovládání (společné pro všechny) - src/main/java/cz/fel/omo/smarthome/entity/devices/items/Device.java (https://gitlab.fel.cvut.cz/momotari/omo_smart_home/-/blob/master/SmartHome/src/main/java/cz/fel/omo/smarthome/entity/devices/items/Device.java)
- API na ovládání (pro jednotlivá zařízení) - src/main/java/cz/fel/omo/smarthome/entity/devices/items (https://gitlab.fel.cvut.cz/momotari/omo_smart_home/-/tree/master/SmartHome/src/main/java/cz/fel/omo/smarthome/entity/devices/items)

**3. F3:**

- Spotřeba spotřebičů - src/main/java/cz/fel/omo/smarthome/entity/devices/items (https://gitlab.fel.cvut.cz/momotari/omo_smart_home/-/tree/master/SmartHome/src/main/java/cz/fel/omo/smarthome/entity/devices/items) <br>
Každý spotřebič má svou hodnotu pro spotřebu elektřiny a/nebo plynu, vody, funkčnosti, které se mění v závislosti na tom, v jakém stavu se nachází zařízení.
- Změna spotřeby v závislosti na stavu - src/main/java/cz/fel/omo/smarthome/entity/devices/items/Device.java (https://gitlab.fel.cvut.cz/momotari/omo_smart_home/-/blob/master/SmartHome/src/main/java/cz/fel/omo/smarthome/entity/devices/items/Device.java)

**4. F4 :**

- API na sběr dat o zařízení - src/main/java/cz/fel/omo/smarthome/entity/devices/items/Device.java (https://gitlab.fel.cvut.cz/momotari/omo_smart_home/-/blob/master/SmartHome/src/main/java/cz/fel/omo/smarthome/entity/devices/items/Device.java)
- ConsumptionReport - src/main/java/cz/fel/omo/smarthome/report/ConsumptionReport.java (https://gitlab.fel.cvut.cz/momotari/omo_smart_home/-/blob/master/SmartHome/src/main/java/cz/fel/omo/smarthome/report/ConsumptionReport.java)

**5. F5:**
- Konfigurace událostí - src/main/resources/configurations/simple.json (https://gitlab.fel.cvut.cz/momotari/omo_smart_home/-/blob/master/SmartHome/src/main/resources/configurations/simple.json)

**6. F6:**

- Generování událostí - src/main/resources/configurations/simple.json (https://gitlab.fel.cvut.cz/momotari/omo_smart_home/-/blob/master/SmartHome/src/main/resources/configurations/simple.json)

**7. F7:**

To je implementováno v každém zařízení zvlášť.
Napr. :
- Akce s jídlem v lednici - src/main/java/cz/fel/omo/smarthome/entity/devices/items/Fridge.java (https://gitlab.fel.cvut.cz/momotari/omo_smart_home/-/blob/master/SmartHome/src/main/java/cz/fel/omo/smarthome/entity/devices/items/Fridge.java)

**8. F8:**

- Vygenerování reportů a zápis do souborů - src/main/java/cz/fel/omo/smarthome/SmartHome.java (https://gitlab.fel.cvut.cz/momotari/omo_smart_home/-/blob/master/SmartHome/src/main/java/cz/fel/omo/smarthome/SmartHome.java)
- HouseConfigurationReport - src/main/java/cz/fel/omo/smarthome/report/HouseConfigurationReport.java (https://gitlab.fel.cvut.cz/momotari/omo_smart_home/-/blob/master/SmartHome/src/main/java/cz/fel/omo/smarthome/report/HouseConfigurationReport.java)
- EventReport - src/main/java/cz/fel/omo/smarthome/report/EventReport.java (https://gitlab.fel.cvut.cz/momotari/omo_smart_home/-/blob/master/SmartHome/src/main/java/cz/fel/omo/smarthome/report/EventReport.java)
- ActivityAndUsageReport - src/main/java/cz/fel/omo/smarthome/report/ActivityAndUsageReport.java (https://gitlab.fel.cvut.cz/momotari/omo_smart_home/-/blob/master/SmartHome/src/main/java/cz/fel/omo/smarthome/report/ActivityAndUsageReport.java)
- ConsumptionReport - src/main/java/cz/fel/omo/smarthome/report/ConsumptionReport.java (https://gitlab.fel.cvut.cz/momotari/omo_smart_home/-/blob/master/SmartHome/src/main/java/cz/fel/omo/smarthome/report/ConsumptionReport.java)

**9. F9:**

Každý spotřebič má svou dokumentaci.
- Všechny přístroje jsou ve složce - src/main/java/cz/fel/omo/smarthome/entity/devices/items (https://gitlab.fel.cvut.cz/momotari/omo_smart_home/-/tree/master/SmartHome/src/main/java/cz/fel/omo/smarthome/entity/devices/items)
src/main/java/cz/fel/omo/smarthome/entity/devices/Documentation.java (https://gitlab.fel.cvut.cz/momotari/omo_smart_home/-/blob/master/SmartHome/src/main/java/cz/fel/omo/smarthome/entity/devices/Documentation.java)

**10. F10:**

- Všechny akce, které mají být provedeny v domě jsou v konfiguračním souboru JSON - src/main/resources/configurations/simple.json (https://gitlab.fel.cvut.cz/momotari/omo_smart_home/-/blob/master/SmartHome/src/main/resources/configurations/simple.json)

## 5.   Nefunkční požadavky

**1. NF1:** Konfigurace domu, zařízení a obyvatel domu nahrává přímo z externího souboru json : src/main/resources/configurations/simple.json (https://gitlab.fel.cvut.cz/momotari/omo_smart_home/-/blob/master/SmartHome/src/main/resources/configurations/simple.json)

**2. NF2:** Reporty jsou generovány do textových souborů.

**3. NF3:** Javadoc : https://gitlab.fel.cvut.cz/momotari/omo_smart_home/-/tree/master/JavaDoc

## 6. Design patterny:

**1. State machine:**
- Device State: Používá se ke změně stavu spotřebičů.
  + TurnOnState
  + TurnOffState
  + BrokenState
  + IdleState
- Window State: Používá se ke změně stavu oken.
  + OpenState
  + CloseState
  + HalfOpenState

**2. Iterator:**
- Device Iterator : Používá se k průchodu všech spotřebičů v domě.

**3. Factory/Factory method:**
Používá se pro pohodlnější vytváření tříd.
- Device Factory
- Inhabitant Factory
- Vehicle Factory
- Sensor Factory

**4. Singleton:**
- SmartHome

**5. Observer/Listener:**
Senzory jsou připevněny k spotřebičů. Sledují jejich stav a reagují na určitý stav(Napr. broken).
- Sensor - Devices

**6. Strategy:**
Určuje chování ostatních objektů v závislosti na události, ke které došlo.
- Events

**7. Builder:**
Používá se pro pohodlnější vytváření domů.
- House Builder

## 7.   Požadované výstupy

+ Generace reportů.
+ Výpis příběhu do konzole.
